# Tharparkar Market Prices (Sample Data Project)

A simple, mobile-friendly data project you can upload to GitHub for verification.

**Owner:** Shaker Ul Din  
**Dataset:** `data/market_prices.csv` (synthetic sample created for learning/testing)
**Tech:** Python, pandas, matplotlib

## What this project shows
- A clean dataset in CSV format
- A short analysis in a Notebook (`notebooks/analysis.ipynb`)
- A Python script (`scripts/analyze.py`) that loads the data and makes a chart
- Clear documentation (this README) + an MIT License

## Dataset description
`market_prices.csv` contains synthetic weekly prices (PKR) for a few staple items observed in different towns of Tharparkar.  
Columns:
- `date` – ISO date (YYYY-MM-DD)
- `town` – Market location (Islamkot, Mithi, Diplo, Chachro)
- `item` – Product name (Wheat Flour, Rice, Sugar, Cooking Oil)
- `price_pkr_per_kg` – Price in PKR per kilogram (integer)

> This is dummy data generated for practice. It is safe to publish.

## Quick start (on a laptop, optional)
```bash
pip install -r requirements.txt
python scripts/analyze.py
```
This will print summary stats and create `output_price_trends.png`.

## Mobile upload steps (GitHub App or mobile browser)
1. Create a new GitHub repo named **tharparkar-market-prices**.
2. Upload **all files** from this project (keep folders the same). In the GitHub mobile app, tap **+** → **Create repository**, then open the repo → **Add file** → **Upload files** and select files from your phone. Repeat for each folder if needed.
3. Ensure the dataset `data/market_prices.csv` is included (required for verification).
4. Open the repo and check that you can see: `README.md`, `LICENSE`, `requirements.txt`, `data/market_prices.csv`, `notebooks/analysis.ipynb`, `scripts/analyze.py`.
5. Copy your repo URL and submit it for project verification.

## Suggested statement for verification
> Dataset is included in the repository at `data/market_prices.csv`. The project contains code and a notebook demonstrating data loading and basic analysis.

## Notes
- You can edit the CSV on your phone (any text editor app) to add more rows later.
- If you want to change the dataset topic, just replace the CSV and adjust the text in this README.

Good luck!
