import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data/market_prices.csv')

print('Rows:', len(df))
print('Columns:', ', '.join(df.columns))

# Basic summary
summary = df.groupby(['town','item'])['price_pkr_per_kg'].describe()
print('\nPrice summary by town & item:')
print(summary)

# Average weekly price by date (all towns) for Wheat Flour
wf = df[df['item']=='Wheat Flour'].groupby('date')['price_pkr_per_kg'].mean().reset_index()

# Plot (no explicit colors/styles as requested)
plt.figure()
plt.plot(wf['date'], wf['price_pkr_per_kg'], marker='o')
plt.xticks(rotation=45, ha='right')
plt.title('Average Wheat Flour Price Over Time')
plt.xlabel('Date')
plt.ylabel('PKR per kg')
plt.tight_layout()
plt.savefig('output_price_trends.png')
print('\nSaved chart to output_price_trends.png')
